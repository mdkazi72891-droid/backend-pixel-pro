<?php
/*
Plugin Name: Backend Pixel Pro
Description: Server-side event optimization with Modular Architecture, Hardware Fingerprint, Dual-Tracking, GA4 Enhanced, MS Clarity, Load Balancing & Extreme Performance.
Version: 7.1
Author: Markeflav
Requires Plugins: woocommerce
*/
if (!defined('ABSPATH')) exit;

define('BP_DIR_PATH', plugin_dir_path(__FILE__));

add_action('before_woocommerce_init', function() {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) { \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true); }
});

require_once BP_DIR_PATH . 'modules/fraud-protection/class-bp-fraud.php';
require_once BP_DIR_PATH . 'modules/data-extraction/class-bp-export.php';
require_once BP_DIR_PATH . 'modules/tracking/class-bp-tracking.php';
require_once __DIR__ . '/modules/analytics/class-bp-analytics.php';
require_once BP_DIR_PATH . 'modules/abandoned-cart/class-bp-abandoned-cart.php';
require_once BP_DIR_PATH . 'modules/admin/class-bp-admin.php';

register_deactivation_hook(__FILE__, function() {
    global $bp_keys;
    if(isset($bp_keys['cron_check'])) wp_clear_scheduled_hook($bp_keys['cron_check']);
    if(isset($bp_keys['cron_send'])) wp_clear_scheduled_hook($bp_keys['cron_send']);
});
